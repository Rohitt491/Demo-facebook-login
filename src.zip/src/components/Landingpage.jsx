import React from 'react'

const Landingpage = () => {
  return (
    <div>

        <h1 style={{textAlign: 'center', fontSize: '100px'}}>Welcome to Facebook</h1>
       
    </div>
  )
}

export default Landingpage